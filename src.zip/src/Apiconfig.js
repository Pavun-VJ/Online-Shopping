const config = {
    // apiBaseUrl: 'https://erpdev.yjktechnologies.com:5567' 
    apiBaseUrl: 'http://localhost:5567'
  };
  
module.exports = config; 
